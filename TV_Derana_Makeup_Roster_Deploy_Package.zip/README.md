# TV Derana Makeup Department Roster Management System

A complete, secure web application designed specifically for the TV Derana Makeup Department to manage daily, weekly, standby, and special production working rosters.

## Included Source Files
- `index.html`: Main Portal & Daily Overview
- `login.html`: Secure Authentication Interface
- `dashboard.html`: Admin Control Center with CRUD management
- `roster.html`: Multi-Category Roster View (Daily, Weekly, Monthly, Standby)
- `artists.html`: Makeup Artists Directory
- `styles.css`: TV Derana Crimson & Makeup Vibe Animations stylesheet
- `script.js`: Interactive frontend management & filter script
- `supabase.js`: Free-tier Supabase database configuration script
- `schema.sql`: Complete PostgreSQL schema & Row Level Security (RLS) setup

## How to Deploy Free

### Step 1: Set Up Free Supabase Database
1. Go to Supabase website and register for a free account.
2. Create a new project named `tv-derana-roster`.
3. Go to SQL Editor, paste the contents of `schema.sql`, and click Run.
4. Navigate to Authentication > Users to manually add authorized TV Derana staff accounts.
5. Copy your Project URL and Anon Key from Project Settings > API into `supabase.js`.

### Step 2: Publish Free on Cloudflare Pages or Netlify
1. Sign up for a free account at Cloudflare Pages or Netlify.
2. Go to Create Application > Upload Assets.
3. Drag and drop all project files (`index.html`, `login.html`, `dashboard.html`, `roster.html`, `artists.html`, `styles.css`, `script.js`, `supabase.js`, `TV_Derana_logo.jpg`).
4. Click Deploy. Your system will be live on a secure HTTPS domain with free SSL.

### Step 3: Swappable Logo Instructions
The site uses `TV_Derana_logo.jpg` as the active brand image. When you update the logo file, simply replace `TV_Derana_logo.jpg` with the new file using the same filename — no redesign required!
