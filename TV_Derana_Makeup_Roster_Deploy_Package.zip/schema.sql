-- ====================================================================
-- TV DERANA MAKEUP DEPARTMENT ROSTER MANAGEMENT SYSTEM
-- SUPABASE POSTGRESQL DATABASE SCHEMA & SECURITY POLICIES
-- ====================================================================

-- 1. Create User Roles Table
CREATE TABLE IF NOT EXISTS user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_name TEXT UNIQUE NOT NULL
);
INSERT INTO user_roles (role_name) VALUES ('admin'), ('staff') ON CONFLICT DO NOTHING;

-- 2. Create User Profiles Table (Linked to Supabase Auth)
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    full_name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT DEFAULT 'staff' REFERENCES user_roles(role_name),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Create Makeup Artists Table
CREATE TABLE IF NOT EXISTS makeup_artists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    artist_name TEXT NOT NULL,
    phone TEXT,
    specialization TEXT,
    status TEXT DEFAULT 'Active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Create Programmes / Productions Table
CREATE TABLE IF NOT EXISTS productions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    production_name TEXT NOT NULL,
    studio_location TEXT NOT NULL,
    director_name TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Create Roster Schedules Table
CREATE TABLE IF NOT EXISTS roster_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    roster_date DATE NOT NULL,
    artist_id UUID REFERENCES makeup_artists(id) ON DELETE CASCADE,
    production_id UUID REFERENCES productions(id) ON DELETE CASCADE,
    duty_description TEXT NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    assigned_location TEXT NOT NULL,
    duty_category TEXT NOT NULL CHECK (duty_category IN ('Daily', 'Weekly', 'Monthly', 'Assigned', 'Standby', 'Special Productions')),
    duty_status TEXT NOT NULL DEFAULT 'Assigned' CHECK (duty_status IN ('Assigned', 'Standby', 'Completed', 'Cancelled')),
    created_by UUID REFERENCES profiles(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Create Access & Download Tracking Logs Table
CREATE TABLE IF NOT EXISTS access_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id),
    action TEXT NOT NULL,
    roster_id UUID REFERENCES roster_schedules(id),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ENABLE ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE makeup_artists ENABLE ROW LEVEL SECURITY;
ALTER TABLE productions ENABLE ROW LEVEL SECURITY;
ALTER TABLE roster_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE access_logs ENABLE ROW LEVEL SECURITY;

-- SECURITY POLICIES: AUTHENTICATED MEMBERS ONLY
CREATE POLICY "Allow authenticated read profiles" ON profiles FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated read roster" ON roster_schedules FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow admin full access to roster" ON roster_schedules FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated read artists" ON makeup_artists FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow authenticated insert access_logs" ON access_logs FOR INSERT WITH CHECK (auth.role() = 'authenticated');

-- SEED INITIAL SAMPLE DATA FOR TESTING
INSERT INTO makeup_artists (artist_name, phone, specialization) VALUES
('Sunil Perera', '+94 77 123 4567', 'News & Anchors'),
('Dilhani Silva', '+94 71 987 6543', 'Drama & Special FX'),
('Kamal Fernando', '+94 70 456 7890', 'Morning Shows & Talk Shows'),
('Nirosha Jayasinghe', '+94 76 333 2211', 'Reality Shows & HD'),
('Kasun Wickramasinghe', '+94 75 888 9900', 'Prime Time News');
