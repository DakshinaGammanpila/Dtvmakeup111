// Supabase Free Tier Configuration & Helper Script
const SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";

let supabase = null;
if (typeof supabase !== 'undefined' && SUPABASE_URL !== "YOUR_SUPABASE_PROJECT_URL") {
    supabase = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

async function loginUser(email, password) {
    if (!supabase) {
        return { user: { email: email }, error: null };
    }
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    return { user: data?.user, error };
}

async function logoutUser() {
    if (supabase) {
        await supabase.auth.signOut();
    }
    window.location.href = "login.html";
}
